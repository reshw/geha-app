export const USER_TYPES = {
  GUEST: 'guest',
  SHAREHOLDER: 'shareholder',
  SUBADMIN: 'subadmin',
  ADMIN: 'admin'
};

export const WEEK_DAYS = ['일', '월', '화', '수', '목', '금', '토'];
